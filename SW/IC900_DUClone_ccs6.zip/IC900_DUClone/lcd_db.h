/********************************************************************
 ************ COPYRIGHT (c) 2023 by ke0ff, Taylor, TX   *************
 *
 *  File name: lcd_db.h
 *
 *  Module:    Control
 *
 *  Summary:   This is the header file for parallel I/O.
 *
 *******************************************************************/


/********************************************************************
 *  File scope declarations revision history:
 *    11-22-23 jmh:  creation date
 *
 *******************************************************************/

//------------------------------------------------------------------------------
// extern defines
//------------------------------------------------------------------------------
#define	MAIN7_LEN	(39*30)

#define	MDWIDE		3
#define	MDADDR0		0
#define	MDADDR1		(MDADDR0+MDWIDE)
#define	MDADDR2		(MDADDR1+MDWIDE)
#define	MDADDR3		(MDADDR2+MDWIDE)
#define	MDADDR4		(MDADDR3+MDWIDE)
#define	MDADDR5		(MDADDR4+MDWIDE)
#define	MDADDR6		(MDADDR5+MDWIDE)
#define	MDADDR7		(MDADDR6+MDWIDE)

#define	DROW		(240/8)
#define	NUMROWS_M	38
#define	NUMROWS_MDP	35

#ifndef	LCD_DB
extern	U8	main7[];		// main 7-seg DU memory
#endif

#define	swapeo(data) (((data << 1) & 0xaa) | ((data >> 1) & 0x55))

#define	LCDCMD		TADDR	//0x01
#define	LCDDATA		0x00
// LCD discrete cmds
#define	LDSC_RESET		1
#define	LDSC_FS68		11
#define	LDSC_FS88		10
#define	LDSC_RVS		21
#define	LDSC_NORM		20
#define	LDSC_INIT		0xff


#define	STA0	0x01		// command execute OK
#define	STA1	0x02		// data read/write OK
#define	STA2	0x04		// auto-mode read OK
#define	STA3	0x08		// auto-mode write OK
#define STA5	0x20		// controller OK
#define	STA6	0x40		// error flag (screen copy)
#define	STA7	0x80		// Blink - normal display

#define	STA01	(STA1|STA0)		// composite OK
#define	STA23	STA3		// composite OK, auto

//------------------------------------------------------------------------------
// public Function Prototypes
//------------------------------------------------------------------------------
void clear_main7(void);
void wr_mdigit(char digit, U16 daddr);

void wrdb(U8 data, U8 addr, U8 mask);
U8 rddb(U8 addr);
void debug_db(U8 data);
void lcd_cntl(U8 cmd);
U8 lcd_stat(U8 mask);

//U8 swapeo(U8 data);

//eof
