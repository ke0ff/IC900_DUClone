/*
 * lcd_test.h
 *
 *  Created on: Nov 23, 2023
 *      Author: KE0FF-Actual
 */

#ifndef LCD_TEST_H_
#define LCD_TEST_H_

int lcd_test(void);

void loop(void);



#endif /* LCD_TEST_H_ */
